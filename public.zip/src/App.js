import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import DropDown from './Components/DropDown/DropDown';
import Header from './Components/Header/Header';

function App() {
  return (
    <div className="App">
     <Navbar/>
     {/* <DropDown/> */}
     <Header/>
    </div>
  );
}

export default App;
