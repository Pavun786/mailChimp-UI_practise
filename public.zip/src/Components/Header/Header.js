import "../Header/Header.css"

 function Header(){


     return(
        <div className="header-container">

            <h1 className="header-heading">Turn Emails into Revenue</h1>
            <p>Win new customers with 
                the #1 email marketing and automations platform* that 
                recommends ways to get more opens, clicks, and sales.
            </p>
            <button className="header-btn">Signup</button>

        </div>
     )
 }
 export default Header;